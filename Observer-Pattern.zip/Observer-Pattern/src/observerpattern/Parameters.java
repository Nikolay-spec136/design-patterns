package observerpattern;

import java.util.ArrayList;
import java.util.List;

public class Parameters implements Subject {

  private List<Observer> observers;

  public Parameters() {
    this.observers = new ArrayList<>();
  }

  @Override
  public void subscribe(Observer observer) {
    this.observers.add(observer);
  }

  @Override
  public void notifyToCustomers(String notification) {
    for (Observer observer : this.observers) {
      observer.update(notification);
    }
  }

  public void releaseNewParameters(String notification) {
    notifyToCustomers(notification);
  }
}
