package observerpattern;

public interface Observer {
  void update(String notification);
}
