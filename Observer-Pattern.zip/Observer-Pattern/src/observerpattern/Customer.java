package observerpattern;

public class Customer implements Observer {

  private String companyName;

  public Customer(String companyName) {
    this.companyName = companyName;
  }

  @Override
  public void update(String notification) {
    System.out.printf("You have new message from %s : %s\n", this.companyName, notification);
  }
}
