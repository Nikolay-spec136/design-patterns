package observerpattern;

public class Main {

  public static void main(String[] args) {
    Observer acer = new Customer("Acer");
    Observer sansumg = new Customer("Sansumg");
    Observer hp = new Customer("Hp");
    
    Parameters model = new Parameters();
    model.subscribe(acer);
    model.subscribe(sansumg);
    model.subscribe(hp);

    model.releaseNewParameters("New parameters are RAM 4 GB, SSD 256 GB");
    System.out.println("");
    model.releaseNewParameters("New parameters are RAM 12 GB, SSD 1000 GB");
  }
}
